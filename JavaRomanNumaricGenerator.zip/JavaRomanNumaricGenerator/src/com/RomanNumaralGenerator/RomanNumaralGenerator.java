/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.RomanNumaralGenerator;
import com.RomanNumaralConversion.RomanNumaralDictonary;
import com.RomanNumaralInterface.NumaralGenerator;
/**
 *
 * @author Khundokar Nirjor
 */
public class RomanNumaralGenerator implements  NumaralGenerator {
    private RomanNumaralDictonary dictionary = new RomanNumaralDictonary();
	
    @Override
		public String generate(int number) {
		
		if(number < 1) throw new IllegalArgumentException("Only supports numbers between 1 and 3999."+
						"The provided number is less than 1.");
		if(number > 3999) throw new IllegalArgumentException("Only supports numbers between 1 and 3999."+
				"The provided number is more than 3999.");
		
		int arabicNumberFound = (int)(dictionary.map.floorKey(number));
		
		if(arabicNumberFound == number) return dictionary.map.get(number).toString();
		
		return dictionary.map.get(arabicNumberFound).toString() + generate(number - arabicNumberFound);
	}
}
