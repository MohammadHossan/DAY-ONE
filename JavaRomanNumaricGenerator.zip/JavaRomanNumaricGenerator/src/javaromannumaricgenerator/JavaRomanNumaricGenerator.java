/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaromannumaricgenerator;

import com.RomanNumaralGenerator.RomanNumaralGenerator;

/**
 *
 * @author Khundokar Nirjor
 */
public class JavaRomanNumaricGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      	
		
		programOutput(1); //returns 1 = “I” 
                programOutput(2);
                programOutput(3);
                programOutput(4);
		programOutput(5); //returns 5 = “V” 
		programOutput(10);//returns 10 = “X”
		programOutput(20);//returns 20 = “XX”
		programOutput(3999);//returns 3999 = “MMMCMXCIX”

	}
	
	
	public static void programOutput(int arabicNumber)
	{
		RomanNumaralGenerator romanGenerator = new RomanNumaralGenerator();
		System.out.println(arabicNumber + " = \"" + romanGenerator.generate(arabicNumber) + "\"");
	}
    }
    

