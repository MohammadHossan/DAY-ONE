import UIKit

//: [Previous](@previous)

import Foundation

let strOne = "2"
let strTwo = "Hello"

if strOne == strTwo {
    print ("YES")
}else{
    print ("No")
}

let strthree = "hello world !!"
let strfour = "hello world !!"

if strthree == strfour{
    print("YES")
}else{
    print("NO")
}

let strFIVE = "hi world !!"
let strSix = "hello world !!"

if strFIVE == strSix{
    print("YES")
}else{
    print("NO")
}



let str6 = "hi world !!"
let str7 = "hi world !!"

if str6 == str7{
    print("YES")
}else{
    print("NO")
}


let str8 = "aardvark apple"
let str9 = "beetroot sandals"

if str8 == str9{
    print("YES")
}else{
    print("NO")
}
